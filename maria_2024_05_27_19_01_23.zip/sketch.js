let nome = "Maria";
let idade = 25;
function setup() {
  const identificacao = [ "A "  + nome + " tem " + idade + " anos "]
  console.log(identificacao);
                        
}

